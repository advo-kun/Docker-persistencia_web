#!/bin/bash

log() {
  echo "$(date +'%Y-%m-%d %H:%M:%S') - $1"
}

wait_for_mysql() {
  local host="$1"
  local user="$2"
  local password="$3"
  until mysql -h "$host" -u "$user" -p"$password" -e "SELECT 1" &> /dev/null; do
    log "Esperando a que MySQL esté disponible en $host..."
    sleep 5
  done
  log "MySQL está disponible en $host"
}

# Esperar a que el servicio MySQL esté disponible en db1
wait_for_mysql "db1" "root" "Asdqwe123"

# Obtener el estado del maestro
MASTER_STATUS=$(mysql -h db1 -u root -pAsdqwe123 -e "SHOW MASTER STATUS\G")
CURRENT_LOG=$(echo "$MASTER_STATUS" | grep 'File:' | awk '{print $2}')
CURRENT_POS=$(echo "$MASTER_STATUS" | grep 'Position:' | awk '{print $2}')

if [[ -z "$CURRENT_LOG" || -z "$CURRENT_POS" ]]; then
  log "Error: No se pudo obtener el estado del maestro"
  exit 1
fi

log "Estado del maestro obtenido: File=$CURRENT_LOG, Position=$CURRENT_POS"

# Esperar a que el servicio MySQL esté disponible en db2
wait_for_mysql "localhost" "root" "Asdqwe123"

# Configurar el esclavo
log "Configurando el esclavo en db2..."
mysql -h localhost -u root -pAsdqwe123 -e "
  STOP SLAVE;
  RESET SLAVE ALL;
  CHANGE MASTER TO
  MASTER_HOST='db1',
  MASTER_USER='advo',
  MASTER_PASSWORD='Asdqwe123',
  MASTER_LOG_FILE='$CURRENT_LOG',
  MASTER_LOG_POS=$CURRENT_POS;
  START SLAVE;
"

if [[ $? -ne 0 ]]; then
  log "Error: No se pudo configurar el esclavo"
  exit 1
fi

log "Esclavo configurado correctamente"
