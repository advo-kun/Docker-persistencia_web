-- Para que la base de datos no aparezca vacia
CREATE DATABASE IF NOT EXISTS example_db;

USE example_db;

CREATE TABLE IF NOT EXISTS names (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO names (name) VALUES ('Example Name');

-- creo mi usuario con la contraseña
DROP USER IF EXISTS 'advo'@'%';
CREATE USER 'advo'@'%' IDENTIFIED BY 'Asdqwe123';
GRANT ALL PRIVILEGES ON example_db.* TO 'advo'@'%';
GRANT REPLICATION SLAVE ON *.* TO 'advo'@'%';
FLUSH PRIVILEGES;


