<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Names</title>
</head>
<body>
    <h1>Insert Name</h1>
    <form action="insert.php" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <button type="submit">Submit</button>
    </form>

    <h2>Names List</h2>
    <ul>
        <?php
        include 'config.php';

        $conn = getDbConnection();

        $sql = "SELECT name FROM names";
        $result = $conn->query($sql);

        if ($result === false) {
            die("Query failed: (" . $conn->errno . ") " . $conn->error);
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li>" . htmlspecialchars($row["name"]) . "</li>";
            }
        } else {
            echo "<li>No names found</li>";
        }

        $conn->close();
        ?>
    </ul>
</body>
</html>
