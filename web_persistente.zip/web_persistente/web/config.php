<?php
function getDbConnection($primary = true) {
    $servername = $primary ? getenv('DB_HOST') : getenv('DB_HOST_REPLICA');
    $username = getenv('DB_USER') ?: 'advo';
    $password = getenv('DB_PASSWORD') ?: 'Asdqwe123';
    $dbname = getenv('DB_NAME') ?: 'example_db';

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        error_log("Connection to $servername failed: " . $conn->connect_error);
        if ($primary) {
            return getDbConnection(false); // Try the replica
        } else {
            die("Connection failed: " . $conn->connect_error);
        }
    }

    return $conn;
}
?>
