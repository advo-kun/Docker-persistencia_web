<?php
include 'config.php';

// Intentar conectarse al maestro primero
$conn = getDbConnection(true);

$name = $_POST['name'];

$sql = "INSERT INTO names (name) VALUES (?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

$stmt->bind_param("s", $name);

if ($stmt->execute() === false) {
    die("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
}

$stmt->close();
$conn->close();

header("Location: index.php");
exit();
?>
